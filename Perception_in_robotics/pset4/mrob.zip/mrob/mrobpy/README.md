## Python short instructions:

compile the project, the recommended path ~/mrob. Then add the following line to .bashrc or .bash_aliases:

'echo "export PYTHONPATH=${PYTHONPATH}:${HOME}/mrob/mrob/lib" >> ~/.bash_aliases'

Make sure that the path to lib is correct.

'python SE_examples'
