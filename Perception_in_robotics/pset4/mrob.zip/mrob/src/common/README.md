# common
Common strucutres and data conventions taken acrros all project. This includes:
* typedef of Eigfen matrrices to Mat1, Mat31 (vector 3x1), MatX, etc.
* typedef of some data types.

## Dependencies
C++'14, Eigen



## Coding conventions
Please check the common conventions for [skmr](https://cdise-bitbucket.skoltech.ru/projects/MR/repos/skmr/browse).

