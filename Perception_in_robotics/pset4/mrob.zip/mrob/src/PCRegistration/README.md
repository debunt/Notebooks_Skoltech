# PCRegistration
Point Cloud Registration. Different methods implemente for point cloud registration:
* Arun, and SVD-based method (Arun'1983)
* GICP
* NICP?


## Dependencies
C++'14, Eigen



## Coding conventions
Please check the common conventions for [mrob](https://cdise-bitbucket.skoltech.ru/projects/MR/repos/mrob/browse).

